import axios from 'axios';

export default async function handler(req, res) {
    const { q } = req.query;
    if (!q) {
        return res.status(400).json({ error: 'Missing query parameter q' });
    }

    // 🔑 यहां अपनी Google API Key और CSE ID डालें
    const GOOGLE_API_KEY = 'AIzaSyBFq4XE_CkSVhITtV7qnZIqtzBU24Mc0TA';
    const CSE_ID = '20f8f170dcfbd4e79';

    try {
        const url = `https://www.googleapis.com/customsearch/v1?key=${GOOGLE_API_KEY}&cx=${CSE_ID}&q=${encodeURIComponent(q)}`;
        const response = await axios.get(url);
        res.status(200).json(response.data);
    } catch (err) {
        res.status(500).json({ error: 'Search API error', details: err.message });
    }
}
